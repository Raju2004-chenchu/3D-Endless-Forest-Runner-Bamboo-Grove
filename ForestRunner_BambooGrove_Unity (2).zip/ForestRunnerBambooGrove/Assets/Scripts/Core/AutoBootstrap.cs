using UnityEngine;
using UnityEngine.SceneManagement;

namespace ForestRunner
{
    /// <summary>
    /// Safety net: if Play is pressed in a scene that has no SceneBootstrap (for example the empty
    /// "Untitled" scene Unity opens by default), this builds the game anyway.
    /// </summary>
    public static class AutoBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Run()
        {
            if (Object.FindObjectOfType<SceneBootstrap>() != null) return;

            // Remove Unity's default empty-scene camera/light so the game's own ones are used.
            foreach (Camera c in Object.FindObjectsOfType<Camera>()) Object.Destroy(c.gameObject);
            foreach (Light l in Object.FindObjectsOfType<Light>()) Object.Destroy(l.gameObject);

            GameObject go = new GameObject("Bootstrap");
            go.SetActive(false);
            SceneBootstrap sb = go.AddComponent<SceneBootstrap>();
            sb.mode = SceneManager.GetActiveScene().name == "Gameplay"
                ? SceneBootstrap.Mode.Gameplay : SceneBootstrap.Mode.MainMenu;
            go.SetActive(true); // Awake runs here and builds the whole game
        }
    }
}
