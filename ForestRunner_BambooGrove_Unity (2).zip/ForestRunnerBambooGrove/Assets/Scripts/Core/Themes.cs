using UnityEngine;
using UnityEngine.SceneManagement;

namespace ForestRunner
{
    /// <summary>One complete colour theme: environment, coins and runner.</summary>
    public class Theme
    {
        public string name;
        public bool keepLevels; // true = use the level assets' own colours (default look)
        public Color skyTop, skyHorizon, fog, ambient, light, path, grass, bamboo, leaf, stone, water, glow;
        public Color coinFace, coinRim, shirt, pants, hat;
    }

    /// <summary>Five switchable themes. Applied to runtime copies, so the .asset files are never modified.</summary>
    public static class Themes
    {
        const string Key = "fr_theme";
        public static readonly Theme[] All;

        static Color C(float r, float g, float b) { return new Color(r, g, b, 1f); }

        static Themes()
        {
            All = new Theme[]
            {
                new Theme { name = "Golden Hour", keepLevels = true,
                    coinFace = C(.78f,.05f,.15f), coinRim = C(.96f,.74f,.28f), shirt = C(.10f,.55f,.58f), pants = C(.18f,.20f,.24f), hat = C(.93f,.88f,.74f) },
                new Theme { name = "Frozen Winter",
                    skyTop = C(.42f,.62f,.86f), skyHorizon = C(.88f,.93f,.98f), fog = C(.85f,.91f,.96f), ambient = C(.55f,.62f,.72f), light = C(.92f,.96f,1f),
                    path = C(.72f,.75f,.80f), grass = C(.88f,.92f,.96f), bamboo = C(.55f,.72f,.62f), leaf = C(.42f,.62f,.52f), stone = C(.62f,.66f,.72f), water = C(.30f,.55f,.75f), glow = C(.6f,.9f,1f),
                    coinFace = C(.10f,.35f,.85f), coinRim = C(.85f,.90f,.95f), shirt = C(.85f,.15f,.15f), pants = C(.15f,.18f,.30f), hat = C(.95f,.95f,.98f) },
                new Theme { name = "Sakura Spring",
                    skyTop = C(.45f,.65f,.92f), skyHorizon = C(1f,.88f,.90f), fog = C(.95f,.82f,.86f), ambient = C(.55f,.50f,.55f), light = C(1f,.92f,.90f),
                    path = C(.62f,.50f,.42f), grass = C(.45f,.65f,.32f), bamboo = C(.55f,.75f,.38f), leaf = C(.95f,.60f,.74f), stone = C(.60f,.58f,.58f), water = C(.35f,.60f,.80f), glow = C(1f,.70f,.85f),
                    coinFace = C(.55f,.20f,.80f), coinRim = C(.96f,.78f,.35f), shirt = C(.95f,.95f,.95f), pants = C(.12f,.16f,.35f), hat = C(.95f,.55f,.70f) },
                new Theme { name = "Neon Night",
                    skyTop = C(.04f,.02f,.14f), skyHorizon = C(.40f,.10f,.50f), fog = C(.15f,.05f,.28f), ambient = C(.22f,.14f,.40f), light = C(.70f,.50f,1f),
                    path = C(.12f,.10f,.22f), grass = C(.06f,.12f,.20f), bamboo = C(.10f,.80f,.85f), leaf = C(.90f,.20f,.70f), stone = C(.25f,.20f,.40f), water = C(.10f,.30f,.70f), glow = C(.2f,1f,.9f),
                    coinFace = C(.20f,1f,.45f), coinRim = C(.90f,1f,.95f), shirt = C(.10f,.10f,.14f), pants = C(.10f,.10f,.18f), hat = C(1f,.20f,.70f) },
                new Theme { name = "Ember Canyon",
                    skyTop = C(.35f,.10f,.12f), skyHorizon = C(1f,.50f,.20f), fog = C(.80f,.40f,.25f), ambient = C(.50f,.30f,.25f), light = C(1f,.60f,.30f),
                    path = C(.50f,.28f,.18f), grass = C(.42f,.30f,.15f), bamboo = C(.70f,.50f,.20f), leaf = C(.80f,.30f,.12f), stone = C(.50f,.30f,.25f), water = C(.20f,.35f,.45f), glow = C(1f,.50f,.10f),
                    coinFace = C(.10f,.80f,.90f), coinRim = C(.85f,.88f,.90f), shirt = C(.90f,.90f,.85f), pants = C(.20f,.15f,.12f), hat = C(.80f,.20f,.10f) },
            };
        }

        public static int Index
        {
            get { return Mathf.Clamp(PlayerPrefs.GetInt(Key, 0), 0, All.Length - 1); }
            set { PlayerPrefs.SetInt(Key, value % All.Length); PlayerPrefs.Save(); }
        }

        public static Theme Current { get { return All[Index]; } }

        static Color Dim(Color c, float d) { return new Color(c.r * d, c.g * d, c.b * d, c.a); }
        static Color Mix(Color orig, Color theme, float dim, float keep) { return Color.Lerp(Dim(theme, dim), orig, keep); }

        /// <summary>Returns a recoloured runtime copy of the level (night level is darkened, sunset/dusk levels keep some of their own tint).</summary>
        public static LevelConfig Apply(LevelConfig lv)
        {
            Theme t = Current;
            if (lv == null || t.keepLevels) return lv;
            LevelConfig c = Object.Instantiate(lv);
            float d = lv.night ? 0.28f : 1f;
            float keep = (lv.levelIndex == 2 || lv.levelIndex == 3) ? 0.4f : 0f;
            c.skyTop = Mix(lv.skyTop, t.skyTop, d, keep);
            c.skyHorizon = Mix(lv.skyHorizon, t.skyHorizon, d, keep);
            c.fogColor = Mix(lv.fogColor, t.fog, d, keep);
            c.ambientColor = Mix(lv.ambientColor, t.ambient, d, keep);
            c.lightColor = Color.Lerp(Mix(lv.lightColor, t.light, 1f, keep), new Color(.5f, .6f, 1f, 1f), lv.night ? 0.6f : 0f);
            c.pathColor = Dim(t.path, d);
            c.grassColor = Dim(t.grass, d);
            c.bambooColor = Dim(t.bamboo, lv.night ? 0.5f : 1f);
            c.leafColor = Dim(t.leaf, lv.night ? 0.5f : 1f);
            c.stoneColor = Dim(t.stone, d);
            Color w = Dim(t.water, d); w.a = lv.waterColor.a; c.waterColor = w;
            c.glowColor = t.glow;
            return c;
        }

        /// <summary>Recolours the default runner (Explorer skin) for the current theme.</summary>
        public static SkinConfig Skin(SkinConfig s)
        {
            Theme t = Current;
            if (s == null || s.skinIndex != 0) return s;
            SkinConfig c = Object.Instantiate(s);
            c.shirt = t.shirt; c.pants = t.pants; c.hat = t.hat;
            return c;
        }
    }

    /// <summary>Main-menu helper: press T to cycle themes (the menu reloads with the new look).</summary>
    public class ThemePicker : MonoBehaviour
    {
        GUIStyle style;

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
                Themes.Index = Themes.Index + 1;
                SceneManager.LoadScene("MainMenu");
            }
        }

        void OnGUI()
        {
            if (style == null)
            {
                style = new GUIStyle(GUI.skin.label);
                style.fontSize = Mathf.Max(16, Screen.height / 36);
                style.fontStyle = FontStyle.Bold;
                style.normal.textColor = Color.white;
            }
            string msg = "Theme: " + Themes.Current.name + "   (press T to change)";
            Rect r = new Rect(16f, Screen.height - 44f, Screen.width, 36f);
            GUI.color = Color.black; GUI.Label(new Rect(r.x + 2f, r.y + 2f, r.width, r.height), msg, style);
            GUI.color = Color.white; GUI.Label(r, msg, style);
        }
    }
}
